-------------------------------------------------------------------
EQRaceInventory -- EverQuest Race Information Inventory Application
-------------------------------------------------------------------
All code created 2009 by Jonathan D. Jackson (AKA Shendare)

Coding conventions:

- UPPER_CASE == Constants, #defines

- TitleCase == Public functions, parameters, variables, global variables, enums, and structs

- iCamelCase == Private variables

- _iCamelCase == Private functions, local function-scope variables

Even when it is not strictly necessary, I try to always use the
this-> prefix when referring to class members, to prevent any
confusion as to the source of a function or variable.
